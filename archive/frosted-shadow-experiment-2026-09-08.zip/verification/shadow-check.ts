import * as THREE from "three";
import { SSAOPass } from "three/addons/postprocessing/SSAOPass.js";
import { RayShadowPass } from "../src/ray-shadows";

const renderer = new THREE.WebGLRenderer();
renderer.setSize(512, 512);
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 30);
camera.position.set(5, 7, 9);
camera.lookAt(0, 0, 0);
camera.updateMatrixWorld();
const light = new THREE.DirectionalLight();
light.position.set(-3, 8, 4);
scene.add(light);
const material = new THREE.MeshBasicMaterial({ color: "white" });
const floor = new THREE.Mesh(new THREE.PlaneGeometry(20, 20), material);
floor.rotation.x = -Math.PI / 2;
const blocker = new THREE.Mesh(new THREE.BoxGeometry(1, 2, 1), material);
blocker.position.y = 1;
blocker.castShadow = true;
scene.add(floor, blocker);
const input = new THREE.WebGLRenderTarget(512, 512, {
  type: THREE.HalfFloatType,
});
const output = input.clone();
const ao = new SSAOPass(scene, camera, 512, 512);
ao.kernelRadius = 0;
const shadow = new RayShadowPass(scene, camera, light, ao.normalRenderTarget);
shadow.setSize(512, 512);
const point = new THREE.Vector3(0.65, 0, -0.85).project(camera);
const x = Math.floor((point.x + 1) * 256),
  y = Math.floor((point.y + 1) * 256);
const pixel = new Uint16Array(4);
function render(cast: boolean, offset = 0) {
  blocker.castShadow = cast;
  blocker.position.x = offset;
  renderer.setRenderTarget(input);
  renderer.render(scene, camera);
  ao.render(renderer, output, input, 0, false);
  shadow.render(renderer, output, input);
  renderer.readRenderTargetPixels(output, x, y, 1, 1, pixel);
  return THREE.DataUtils.fromHalfFloat(pixel[0]);
}
const clear = render(false);
const covered = render(true);
const repeat = render(true);
const moved = render(true, 3);
const restored = render(true);
const result = {
  clear,
  covered,
  repeat,
  moved,
  restored,
  darkens: covered < clear * 0.85,
  stationaryExact: covered === repeat,
  movesWithCaster: moved > covered * 1.2 && Math.abs(moved - clear) < 0.01,
  restores: restored === covered,
  stats: shadow.getStats(),
};
shadow.renderToScreen = true;
shadow.render(renderer, output, input);
document.querySelector("#result")!.textContent = JSON.stringify(
  result,
  null,
  2,
);
document.body.dataset.passed = String(
  result.darkens &&
    result.stationaryExact &&
    result.movesWithCaster &&
    result.restores,
);
