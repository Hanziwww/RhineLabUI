import * as THREE from "three";
import { Pass, FullScreenQuad } from "three/addons/postprocessing/Pass.js";
import { ShadowBVH } from "./shadow-bvh";

const vertexShader = `
varying vec2 vUv;
void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
`;

const traceShader = `
precision highp float;
precision highp int;
uniform sampler2D tDepth, tNormal, boxes, tree;
uniform mat4 inverseProjection, cameraWorld;
uniform vec3 lightDirection;
uniform int nodeCount;
uniform float cameraNear, cameraFar;
varying vec2 vUv;

vec2 interval(vec3 origin, vec3 direction, vec3 lo, vec3 hi) {
  vec3 safe = mix(vec3(1e-7), direction, greaterThan(abs(direction), vec3(1e-7)));
  vec3 a = (lo - origin) / safe, b = (hi - origin) / safe;
  vec3 nearT = min(a, b), farT = max(a, b);
  return vec2(max(max(nearT.x, nearT.y), nearT.z), min(min(farT.x, farT.y), farT.z));
}
bool occluded(vec3 origin, vec3 direction) {
  int node = 0;
  for (int step = 0; step < 1024; step++) {
    if (node < 0 || node >= nodeCount) break;
    vec4 lo = texelFetch(tree, ivec2(0, node), 0);
    vec4 hi = texelFetch(tree, ivec2(1, node), 0);
    vec2 range = interval(origin, direction, lo.xyz, hi.xyz);
    if (range.y < max(range.x, 0.0) || range.x > 60.0) {
      node = int(hi.w); continue;
    }
    if (lo.w < 0.0) { node++; continue; }
    int id = int(lo.w);
    vec4 row0 = texelFetch(boxes, ivec2(0, id), 0);
    vec4 row1 = texelFetch(boxes, ivec2(1, id), 0);
    vec4 row2 = texelFetch(boxes, ivec2(2, id), 0);
    vec3 localOrigin = vec3(dot(row0, vec4(origin, 1.0)), dot(row1, vec4(origin, 1.0)), dot(row2, vec4(origin, 1.0)));
    vec3 localDirection = vec3(dot(row0.xyz, direction), dot(row1.xyz, direction), dot(row2.xyz, direction));
    range = interval(localOrigin, localDirection,
      texelFetch(boxes, ivec2(3, id), 0).xyz, texelFetch(boxes, ivec2(4, id), 0).xyz);
    // Ignore a receiver inside its own slightly conservative bevel bounds.
    if (range.x > 0.003 && range.y >= range.x && range.x < 60.0) return true;
    node = int(hi.w);
  }
  return false;
}
void main() {
  float depth = texture2D(tDepth, vUv).x;
  vec4 view = inverseProjection * vec4(vUv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
  view /= view.w;
  if (depth >= 1.0 || nodeCount == 0) { gl_FragColor = vec4(1.0, -view.z, 0.0, 1.0); return; }
  vec3 normal = normalize(mat3(cameraWorld) * (texture2D(tNormal, vUv).xyz * 2.0 - 1.0));
  vec3 origin = (cameraWorld * view).xyz + normal * 0.008 + lightDirection * 0.004;
  vec3 tangent = normalize(cross(lightDirection, vec3(0.0, 0.0, 1.0)));
  vec3 bitangent = cross(tangent, lightDirection);
  float visibility = 0.0;
  // Fixed area-light samples: no frame noise or history accumulation to leave
  // trails when a file is lifted, rotated, or rapidly reselected.
  for (int i = 0; i < 8; i++) {
    float angle = float(i) * 2.39996323;
    float radius = sqrt((float(i) + 0.5) / 8.0) * 0.085;
    vec3 direction = normalize(lightDirection + radius * (cos(angle) * tangent + sin(angle) * bitangent));
    visibility += occluded(origin, direction) ? 0.0 : 0.125;
  }
  gl_FragColor = vec4(visibility, -view.z, max(dot(normal, lightDirection), 0.0), 1.0);
}
`;

const compositeShader = `
uniform sampler2D tDiffuse, tShadow, tDepth;
uniform vec2 shadowSize;
uniform float cameraNear, cameraFar, fogNear, fogFar;
varying vec2 vUv;
float distanceAt(float depth) { return cameraNear * cameraFar / (cameraFar - depth * (cameraFar - cameraNear)); }
void main() {
  vec4 color = texture2D(tDiffuse, vUv);
  float distance = distanceAt(texture2D(tDepth, vUv).x);
  vec2 pixel = vUv * shadowSize - 0.5, base = floor(pixel), blend = fract(pixel);
  float shadow = 0.0, weight = 0.0;
  for (int y = 0; y < 2; y++) for (int x = 0; x < 2; x++) {
    vec2 corner = vec2(float(x), float(y));
    vec3 sampleValue = texture2D(tShadow, (base + corner + 0.5) / shadowSize).rgb;
    vec2 bilinear = mix(1.0 - blend, blend, corner);
    float w = bilinear.x * bilinear.y * exp(-abs(sampleValue.g - distance) * 12.0);
    shadow += (1.0 - sampleValue.r) * (0.14 + 0.40 * sampleValue.b) * w;
    weight += w;
  }
  shadow /= max(weight, 0.00001);
  shadow *= 1.0 - smoothstep(fogNear, fogFar, distance);
  gl_FragColor = vec4(color.rgb * (1.0 - shadow), color.a);
}
`;

export class RayShadowPass extends Pass {
  readonly bvh = new ShadowBVH();
  private shadow = new THREE.WebGLRenderTarget(1, 1, {
    type: THREE.HalfFloatType,
    minFilter: THREE.NearestFilter,
    magFilter: THREE.NearestFilter,
    depthBuffer: false,
  });
  private trace: THREE.ShaderMaterial;
  private composite: THREE.ShaderMaterial;
  private quad = new FullScreenQuad();
  private lightDirection = new THREE.Vector3();
  private targetPosition = new THREE.Vector3();
  private frame = 0;
  private query: WebGLQuery | null = null;
  private gpuMs: number | null = null;
  private cpuMs = 0;

  constructor(
    private scene: THREE.Scene,
    private camera: THREE.PerspectiveCamera,
    private light: THREE.DirectionalLight,
    normalTarget: THREE.WebGLRenderTarget,
  ) {
    super();
    this.trace = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader: traceShader,
      depthTest: false,
      depthWrite: false,
      uniforms: {
        tDepth: { value: normalTarget.depthTexture },
        tNormal: { value: normalTarget.texture },
        boxes: { value: this.bvh.boxes },
        tree: { value: this.bvh.tree },
        inverseProjection: { value: camera.projectionMatrixInverse },
        cameraWorld: { value: camera.matrixWorld },
        lightDirection: { value: this.lightDirection },
        nodeCount: { value: 0 },
        cameraNear: { value: camera.near },
        cameraFar: { value: camera.far },
      },
    });
    this.composite = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader: compositeShader,
      depthTest: false,
      depthWrite: false,
      uniforms: {
        tDiffuse: { value: null },
        tShadow: { value: this.shadow.texture },
        tDepth: { value: normalTarget.depthTexture },
        shadowSize: { value: new THREE.Vector2(1, 1) },
        cameraNear: { value: camera.near },
        cameraFar: { value: camera.far },
        fogNear: { value: 1000 },
        fogFar: { value: 1001 },
      },
    });
  }

  setSize(width: number, height: number) {
    // Bound work on 4K displays while retaining depth-guided full-size edges.
    const scale = Math.min(0.5, 960 / width, 640 / height);
    const w = Math.max(1, Math.round(width * scale)),
      h = Math.max(1, Math.round(height * scale));
    this.shadow.setSize(w, h);
    this.composite.uniforms.shadowSize.value.set(w, h);
  }

  render(
    renderer: THREE.WebGLRenderer,
    writeBuffer: THREE.WebGLRenderTarget,
    readBuffer: THREE.WebGLRenderTarget,
  ) {
    const start = performance.now();
    this.bvh.update(this.scene);
    this.cpuMs = performance.now() - start;
    const gl = renderer.getContext() as WebGL2RenderingContext;
    const timer = (
      renderer.extensions.has("EXT_disjoint_timer_query_webgl2")
        ? renderer.extensions.get("EXT_disjoint_timer_query_webgl2")
        : null
    ) as { GPU_DISJOINT_EXT: number; TIME_ELAPSED_EXT: number } | null;
    if (
      timer &&
      this.query &&
      gl.getQueryParameter(this.query, gl.QUERY_RESULT_AVAILABLE)
    ) {
      if (!gl.getParameter(timer.GPU_DISJOINT_EXT))
        this.gpuMs = gl.getQueryParameter(this.query, gl.QUERY_RESULT) / 1e6;
      gl.deleteQuery(this.query);
      this.query = null;
    }
    const measure = timer && !this.query && this.frame++ % 30 === 0;
    if (measure) {
      this.query = gl.createQuery();
      gl.beginQuery(timer.TIME_ELAPSED_EXT, this.query!);
    }
    this.light.getWorldPosition(this.lightDirection);
    this.light.target.getWorldPosition(this.targetPosition);
    this.lightDirection.sub(this.targetPosition).normalize();
    this.trace.uniforms.nodeCount.value = this.bvh.nodeCount;
    renderer.setRenderTarget(this.shadow);
    this.quad.material = this.trace;
    this.quad.render(renderer);
    const uniforms = this.composite.uniforms;
    uniforms.tDiffuse.value = readBuffer.texture;
    uniforms.cameraNear.value = this.camera.near;
    uniforms.cameraFar.value = this.camera.far;
    if (this.scene.fog instanceof THREE.Fog) {
      uniforms.fogNear.value = this.scene.fog.near;
      uniforms.fogFar.value = this.scene.fog.far;
    }
    renderer.setRenderTarget(this.renderToScreen ? null : writeBuffer);
    this.quad.material = this.composite;
    this.quad.render(renderer);
    if (measure) gl.endQuery(timer.TIME_ELAPSED_EXT);
  }

  getStats() {
    return {
      enabled: this.enabled,
      casters: this.bvh.count,
      nodes: this.bvh.nodeCount,
      samples: 8,
      width: this.shadow.width,
      height: this.shadow.height,
      gpuMs: this.gpuMs === null ? null : Math.round(this.gpuMs * 100) / 100,
      updateMs: Math.round(this.cpuMs * 100) / 100,
    };
  }

  dispose() {
    this.bvh.dispose();
    this.shadow.dispose();
    this.trace.dispose();
    this.composite.dispose();
    this.quad.dispose();
  }
}
