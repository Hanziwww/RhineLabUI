import * as THREE from "three";

const CAPACITY = 512;
type Caster = { bounds: THREE.Box3; inverse: THREE.Matrix4; local: THREE.Box3 };
type Node = { bounds: THREE.Box3; caster: number; escape: number };

// The archive's opaque inserts are rectangular. Trace their oriented bounds,
// including off-screen instances, instead of rebuilding a triangle BVH as the
// array moves. This is a shadow-volume approximation, not a path tracer.
export class ShadowBVH {
  readonly boxes = new THREE.DataTexture(
    new Float32Array(CAPACITY * 20),
    5,
    CAPACITY,
    THREE.RGBAFormat,
    THREE.FloatType,
  );
  readonly tree = new THREE.DataTexture(
    new Float32Array(CAPACITY * 16),
    2,
    CAPACITY * 2,
    THREE.RGBAFormat,
    THREE.FloatType,
  );
  count = 0;
  nodeCount = 0;
  private casters: Caster[] = [];
  private nodes: Node[] = [];
  private order: number[] = [];
  private matrix = new THREE.Matrix4();
  private instance = new THREE.Matrix4();
  private extent = new THREE.Vector3();

  update(scene: THREE.Scene) {
    this.count = 0;
    scene.traverseVisible((object) => {
      if (!(object instanceof THREE.Mesh) || !object.castShadow) return;
      if (!object.geometry.boundingBox) object.geometry.computeBoundingBox();
      const local = object.geometry.boundingBox!;
      if (object instanceof THREE.InstancedMesh) {
        for (let i = 0; i < object.count; i++) {
          object.getMatrixAt(i, this.instance);
          this.matrix.multiplyMatrices(object.matrixWorld, this.instance);
          this.add(local, this.matrix);
        }
      } else this.add(local, object.matrixWorld);
    });
    this.nodeCount = 0;
    this.order.length = this.count;
    for (let i = 0; i < this.count; i++) this.order[i] = i;
    if (this.count) this.build(0, this.count);
    const data = this.tree.image.data as Float32Array;
    for (let i = 0; i < this.nodeCount; i++) {
      const node = this.nodes[i],
        offset = i * 8;
      node.bounds.min.toArray(data, offset);
      data[offset + 3] = node.caster;
      node.bounds.max.toArray(data, offset + 4);
      data[offset + 7] = node.escape === this.nodeCount ? -1 : node.escape;
    }
    this.boxes.needsUpdate = true;
    this.tree.needsUpdate = true;
  }

  private add(local: THREE.Box3, matrix: THREE.Matrix4) {
    if (this.count >= CAPACITY || Math.abs(matrix.determinant()) < 1e-8) return;
    const i = this.count++;
    const caster = (this.casters[i] ??= {
      bounds: new THREE.Box3(),
      inverse: new THREE.Matrix4(),
      local: new THREE.Box3(),
    });
    caster.bounds.copy(local).applyMatrix4(matrix);
    caster.local.copy(local);
    caster.inverse.copy(matrix).invert();
    const data = this.boxes.image.data as Float32Array,
      m = caster.inverse.elements;
    for (let row = 0; row < 3; row++)
      for (let col = 0; col < 4; col++)
        data[i * 20 + row * 4 + col] = m[col * 4 + row];
    local.min.toArray(data, i * 20 + 12);
    local.max.toArray(data, i * 20 + 16);
  }

  private build(start: number, end: number): number {
    const index = this.nodeCount++;
    const node = (this.nodes[index] ??= {
      bounds: new THREE.Box3(),
      caster: -1,
      escape: -1,
    });
    node.bounds.makeEmpty();
    for (let i = start; i < end; i++)
      node.bounds.union(this.casters[this.order[i]].bounds);
    node.caster = end - start === 1 ? this.order[start] : -1;
    if (node.caster < 0) {
      node.bounds.getSize(this.extent);
      const axis =
        this.extent.x > this.extent.y && this.extent.x > this.extent.z
          ? "x"
          : this.extent.y > this.extent.z
            ? "y"
            : "z";
      const sorted = this.order.slice(start, end).sort((a, b) => {
        const aa = this.casters[a].bounds,
          bb = this.casters[b].bounds;
        return aa.min[axis] + aa.max[axis] - bb.min[axis] - bb.max[axis];
      });
      for (let i = 0; i < sorted.length; i++) this.order[start + i] = sorted[i];
      const mid = (start + end) >> 1;
      this.build(start, mid);
      this.build(mid, end);
    }
    node.escape = this.nodeCount;
    return index;
  }

  dispose() {
    this.boxes.dispose();
    this.tree.dispose();
  }
}
