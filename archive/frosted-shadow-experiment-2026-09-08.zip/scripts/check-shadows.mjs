import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import * as THREE from "three";
import { ShadowBVH } from "../src/shadow-bvh.ts";

async function asset(name) {
  const bytes = await readFile(
    new URL(`../public/assets/${name}.glb`, import.meta.url),
  );
  const size = bytes.readUInt32LE(12);
  return {
    json: JSON.parse(bytes.subarray(20, 20 + size)),
    bin: bytes.subarray(28 + size),
  };
}
const old = await asset("archive-cassette"),
  frosted = await asset("archive-cassette-frosted");
function attribute(asset, id) {
  const accessor = asset.json.accessors[id],
    view = asset.json.bufferViews[accessor.bufferView];
  return {
    accessor,
    bytes: asset.bin.subarray(
      view.byteOffset,
      view.byteOffset + view.byteLength,
    ),
  };
}
for (const mesh of old.json.meshes) {
  const surface = old.json.materials[mesh.primitives[0].material].name.replace(
    /\.\d+$/,
    "",
  );
  const match = frosted.json.meshes.find(
    (candidate) =>
      frosted.json.materials[candidate.primitives[0].material].name.replace(
        /\.\d+$/,
        "",
      ) === surface,
  );
  assert.ok(match, mesh.name);
  const a = mesh.primitives[0],
    b = match.primitives[0];
  for (const key of Object.keys(a.attributes)) {
    assert.deepEqual(
      attribute(old, a.attributes[key]).bytes,
      attribute(frosted, b.attributes[key]).bytes,
      `${mesh.name} ${key} geometry retained`,
    );
  }
  assert.deepEqual(
    attribute(old, a.indices).bytes,
    attribute(frosted, b.indices).bytes,
  );
  const oldNode = old.json.nodes.find(
    (n) => n.mesh === old.json.meshes.indexOf(mesh),
  );
  const newNode = frosted.json.nodes.find(
    (n) => n.mesh === frosted.json.meshes.indexOf(match),
  );
  for (const key of ["translation", "rotation", "scale", "matrix"])
    assert.deepEqual(oldNode[key], newNode[key]);
}
for (const surface of ["Frosted_Polymer", "Ivory_Edges"]) {
  const material = frosted.json.materials.find((m) =>
    m.name.startsWith(surface),
  );
  assert.equal(material.extras.frosted, true);
  assert.ok(
    material.normalTexture &&
      material.pbrMetallicRoughness.metallicRoughnessTexture,
  );
  assert.ok(material.pbrMetallicRoughness.roughnessFactor > 0.4);
}

const scene = new THREE.Scene(),
  bvh = new ShadowBVH();
const geometry = new THREE.BoxGeometry(5, 3.7, 0.27);
geometry.computeBoundingBox();
const array = new THREE.InstancedMesh(
  geometry,
  new THREE.MeshBasicMaterial(),
  288,
);
array.castShadow = true;
scene.add(array);
const selected = new THREE.Mesh(geometry, array.material);
selected.castShadow = true;
scene.add(selected);
const dummy = new THREE.Object3D();
let seed = 321;
const random = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 2 ** 32;
const boxes = bvh.boxes.image.data,
  tree = bvh.tree.image.data;
function interval(origin, direction, lo, hi) {
  let near = -Infinity,
    far = Infinity;
  for (let axis = 0; axis < 3; axis++) {
    const safe = Math.abs(direction[axis]) > 1e-7 ? direction[axis] : 1e-7;
    const a = (lo[axis] - origin[axis]) / safe,
      b = (hi[axis] - origin[axis]) / safe;
    near = Math.max(near, Math.min(a, b));
    far = Math.min(far, Math.max(a, b));
  }
  return [near, far];
}
function trace(origin, direction) {
  let node = 0;
  for (let step = 0; step < 1024 && node >= 0 && node < bvh.nodeCount; step++) {
    const n = node * 8;
    const [near, far] = interval(
      origin,
      direction,
      tree.subarray(n, n + 3),
      tree.subarray(n + 4, n + 7),
    );
    if (far < Math.max(near, 0) || near > 60) {
      node = tree[n + 7];
      continue;
    }
    if (tree[n + 3] < 0) {
      node++;
      continue;
    }
    const offset = tree[n + 3] * 20,
      local = [],
      ray = [];
    for (let row = 0; row < 3; row++) {
      const r = offset + row * 4;
      local[row] =
        boxes[r] * origin[0] +
        boxes[r + 1] * origin[1] +
        boxes[r + 2] * origin[2] +
        boxes[r + 3];
      ray[row] =
        boxes[r] * direction[0] +
        boxes[r + 1] * direction[1] +
        boxes[r + 2] * direction[2];
    }
    const [a, b] = interval(
      local,
      ray,
      boxes.subarray(offset + 12, offset + 15),
      boxes.subarray(offset + 16, offset + 19),
    );
    if (a > 0.003 && b >= a && a < 60) return true;
    node = tree[n + 7];
  }
  return false;
}
let checked = 0;
for (let frame = 0; frame < 4; frame++) {
  const matrices = [];
  for (let i = 0; i < 288; i++) {
    dummy.position.set(
      (Math.floor(i / 32) - 4) * 5.8,
      Math.sin(i * 0.8 + frame) * 0.25,
      ((i % 32) - 16 + frame * 32) * 0.58,
    );
    dummy.scale.setScalar(i === 100 ? 0 : 1);
    dummy.updateMatrix();
    array.setMatrixAt(i, dummy.matrix);
    if (i !== 100) matrices.push(dummy.matrix.clone());
  }
  selected.position.set(0, frame === 1 ? 4.05 : 0.4, frame * 32 * 0.58);
  selected.rotation.set(0.1 * frame, 0.38 * frame, 0);
  scene.updateMatrixWorld(true);
  matrices.push(selected.matrixWorld.clone());
  bvh.update(scene);
  assert.equal(
    bvh.count,
    288,
    "Hidden instance is replaced by the selected file",
  );
  assert.equal(bvh.nodeCount, 575);
  const inverses = matrices.map((matrix) => matrix.clone().invert());
  for (let i = 0; i < 1000; i++) {
    const origin = new THREE.Vector3(
      (random() - 0.5) * 60,
      random() * 15 - 5,
      (random() - 0.5) * 25 + frame * 32 * 0.58,
    );
    const direction = new THREE.Vector3(
      random() - 0.5,
      random() * 2 - 1,
      random() - 0.5,
    ).normalize();
    const brute = inverses.some((inverse, index) => {
      const ray = new THREE.Ray(origin, direction)
        .clone()
        .applyMatrix4(inverse);
      if (geometry.boundingBox.containsPoint(ray.origin)) return false;
      const point = ray.intersectBox(geometry.boundingBox, new THREE.Vector3());
      if (!point) return false;
      const distance = point.applyMatrix4(matrices[index]).distanceTo(origin);
      return distance > 0.003 && distance < 60;
    });
    assert.equal(
      trace(origin.toArray(), direction.toArray()),
      brute,
      `frame ${frame}, ray ${i}`,
    );
    checked++;
  }
}
selected.visible = array.visible = false;
bvh.update(scene);
assert.equal(bvh.nodeCount, 0);
bvh.dispose();
geometry.dispose();
array.material.dispose();
console.log(
  `Frosted asset preserves all 11 mesh geometries; BVH matches ${checked} independent ray tests across lift, rotation, and pool wrapping.`,
);
