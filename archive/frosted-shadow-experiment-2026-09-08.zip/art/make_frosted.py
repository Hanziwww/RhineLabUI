"""Run through the Blender MCP bridge. Keep the approved geometry unchanged."""
import bpy
import math
from pathlib import Path

ROOT = Path('C:/workdir/project/RhineUI')
ASSETS = ROOT / 'public/assets/frosted'
ASSETS.mkdir(parents=True, exist_ok=True)
previous_scene = bpy.context.window.scene

# A periodic four-dimensional noise field avoids seams when the grain repeats.
bake = bpy.data.scenes.new('Rhine_Frosted_Bake')
bpy.context.window.scene = bake
bake.render.engine = 'CYCLES'
bake.cycles.samples = 8
bake.render.bake.margin = 0
bpy.ops.mesh.primitive_plane_add(size=1)
plane = bpy.context.object
plane.name = 'Frosted_Surface_Bake'
material = bpy.data.materials.new('Rhine_White_Frost_Procedural')
material.use_nodes = True
plane.data.materials.append(material)
nodes, links = material.node_tree.nodes, material.node_tree.links
nodes.clear()
output = nodes.new('ShaderNodeOutputMaterial')
principled = nodes.new('ShaderNodeBsdfPrincipled')
principled.inputs['Base Color'].default_value = (.965, .962, .953, 1)
principled.inputs['Roughness'].default_value = .64
uv = nodes.new('ShaderNodeTexCoord')
split = nodes.new('ShaderNodeSeparateXYZ')
links.new(uv.outputs['UV'], split.inputs[0])
def trig(axis, operation):
    scale = nodes.new('ShaderNodeMath'); scale.operation = 'MULTIPLY'
    scale.inputs[1].default_value = math.tau
    links.new(split.outputs[axis], scale.inputs[0])
    node = nodes.new('ShaderNodeMath'); node.operation = operation
    links.new(scale.outputs[0], node.inputs[0])
    return node.outputs[0]
coords = nodes.new('ShaderNodeCombineXYZ')
for i, value in enumerate([trig('X', 'COSINE'), trig('X', 'SINE'), trig('Y', 'COSINE')]):
    links.new(value, coords.inputs[i])
noise = nodes.new('ShaderNodeTexNoise'); noise.noise_dimensions = '4D'
noise.inputs['Scale'].default_value = 38
noise.inputs['Detail'].default_value = 2
noise.inputs['Roughness'].default_value = .68
links.new(coords.outputs[0], noise.inputs['Vector'])
links.new(trig('Y', 'SINE'), noise.inputs['W'])
bump = nodes.new('ShaderNodeBump')
bump.inputs['Strength'].default_value = .18
bump.inputs['Distance'].default_value = .0015
links.new(noise.outputs['Fac'], bump.inputs['Height'])
links.new(bump.outputs['Normal'], principled.inputs['Normal'])
links.new(principled.outputs[0], output.inputs['Surface'])

def image_target(name, filename):
    image = bpy.data.images.new(name, 1024, 1024, alpha=False)
    image.colorspace_settings.name = 'Non-Color'
    image.filepath_raw = str(ASSETS / filename)
    image.file_format = 'PNG'
    texture = nodes.new('ShaderNodeTexImage'); texture.image = image
    for node in nodes: node.select = False
    texture.select = True
    nodes.active = texture
    return image

normal = image_target('Rhine_Frosted_Normal', 'normal.png')
bpy.ops.object.bake(type='NORMAL')
normal.save()
roughness = image_target('Rhine_Frosted_Roughness', 'roughness.png')
remap = nodes.new('ShaderNodeMapRange')
remap.inputs['To Min'].default_value = .84
remap.inputs['To Max'].default_value = 1
links.new(noise.outputs['Fac'], remap.inputs['Value'])
emission = nodes.new('ShaderNodeEmission')
links.new(remap.outputs['Result'], emission.inputs['Color'])
links.new(emission.outputs[0], output.inputs['Surface'])
bpy.ops.object.bake(type='EMIT')
roughness.save()
links.new(principled.outputs[0], output.inputs['Surface'])

# Append the delivered source scene; never reset the user's current Blender file.
with bpy.data.libraries.load(str(ROOT / 'art/rhine-archive.blend'), link=False) as (source, target):
    target.scenes = [name for name in source.scenes if name.startswith('Rhine_Archive_Asset')][:1]
scene = target.scenes[0]
scene.name = 'Rhine_Frosted_Archive'
bpy.context.window.scene = scene
changed = []
for obj in scene.objects:
    if obj.type != 'MESH': continue
    for slot in obj.material_slots:
        source_material = slot.material
        name = source_material.name.split('.')[0]
        if name not in {'Frosted_Polymer', 'Ivory_Edges'}: continue
        # Each joined material group receives an independent, exported PBR graph.
        mat = source_material.copy(); slot.material = mat
        mat['frosted'] = True
        mat.use_nodes = True
        mat.diffuse_color = (.965, .962, .953, 1)
        ns, ls = mat.node_tree.nodes, mat.node_tree.links
        ns.clear()
        out = ns.new('ShaderNodeOutputMaterial')
        p = ns.new('ShaderNodeBsdfPrincipled')
        p.inputs['Base Color'].default_value = mat.diffuse_color
        surface_roughness = .48 if name == 'Frosted_Polymer' else .62
        p.inputs['Roughness'].default_value = surface_roughness
        p.inputs['Metallic'].default_value = 0
        p.inputs['IOR'].default_value = 1.46
        p.inputs['Transmission Weight'].default_value = .78 if name == 'Frosted_Polymer' else .04
        p.inputs['Coat Weight'].default_value = .035
        p.inputs['Coat Roughness'].default_value = .55
        ls.new(p.outputs[0], out.inputs['Surface'])
        texcoord = ns.new('ShaderNodeTexCoord')
        mapping = ns.new('ShaderNodeMapping')
        mapping.inputs['Scale'].default_value = (7, 7, 7)
        ls.new(texcoord.outputs['UV'], mapping.inputs['Vector'])
        ntex = ns.new('ShaderNodeTexImage'); ntex.image = normal
        rtex = ns.new('ShaderNodeTexImage'); rtex.image = roughness
        ls.new(mapping.outputs['Vector'], ntex.inputs['Vector'])
        ls.new(mapping.outputs['Vector'], rtex.inputs['Vector'])
        nmap = ns.new('ShaderNodeNormalMap'); nmap.inputs['Strength'].default_value = .22
        ls.new(ntex.outputs['Color'], nmap.inputs['Color'])
        ls.new(nmap.outputs['Normal'], p.inputs['Normal'])
        # glTF stores a roughness factor and a grayscale multiplier texture.
        multiply = ns.new('ShaderNodeMath'); multiply.operation = 'MULTIPLY'
        multiply.inputs[1].default_value = surface_roughness
        ls.new(rtex.outputs['Color'], multiply.inputs[0])
        ls.new(multiply.outputs[0], p.inputs['Roughness'])
        changed.append(name)

bpy.ops.object.select_all(action='DESELECT')
for obj in scene.objects:
    if obj.type == 'MESH': obj.select_set(True)
bpy.ops.export_scene.gltf(
    filepath=str(ROOT / 'public/assets/archive-cassette-frosted.glb'),
    export_format='GLB', use_selection=True, use_active_scene=True,
    export_apply=True, export_extras=True,
)
# Save the source and procedural bake scene, without the unrelated startup scene.
normal.pack()
roughness.pack()
bpy.data.libraries.write(str(ROOT / 'art/rhine-frosted.blend'), {scene, bake}, fake_user=True)
bpy.context.window.scene = previous_scene
result = {'asset': 'archive-cassette-frosted.glb', 'source': 'art/rhine-frosted.blend',
          'maps': ['frosted/normal.png', 'frosted/roughness.png'], 'materials': changed}
